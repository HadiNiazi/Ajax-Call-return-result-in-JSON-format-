<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "social";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
 if (isset($_POST['country'])) {

    $selected_country = $_POST['country'];
    $sql = "Select id,score,age,country,gender from quiz where country = '$selected_country' ";
    $result = mysqli_query($conn,$sql);
    while($row = mysqli_fetch_assoc($result)) {
        $data["id"] = $row['id'];
        $data["score"] = $row['score'];
        $data["age"] = $row['age'];
        $data["country"] = $row['country'];
        $data["gender"] = $row['gender'];
    }
    echo json_encode($data);
  }
else {
echo "Please Select your Country";
}
?>